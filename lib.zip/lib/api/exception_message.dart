class ExceptionMessage {
  final String message;

  ExceptionMessage(this.message);
}
