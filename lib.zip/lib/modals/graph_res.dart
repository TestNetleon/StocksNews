class GraphRes {
  String name;
  bool isSelected;
  GraphRes({required this.name, this.isSelected = false});
}
//