// To parse this JSON data, do
//
//     final stocksRes = stocksResFromJson(jsonString);

import 'dart:convert';

StocksRes stocksResFromJson(String str) => StocksRes.fromJson(json.decode(str));

String stocksResToJson(StocksRes data) => json.encode(data.toJson());

class StocksRes {
  final int currentPage;
  final List<AllStocks>? data;
  final int lastPage;
//
  StocksRes({
    required this.currentPage,
    this.data,
    required this.lastPage,
  });

  factory StocksRes.fromJson(Map<String, dynamic> json) => StocksRes(
        currentPage: json["current_page"],
        data: json["data"] == null
            ? []
            : List<AllStocks>.from(
                json["data"]!.map((x) => AllStocks.fromJson(x))),
        lastPage: json["last_page"],
      );

  Map<String, dynamic> toJson() => {
        "current_page": currentPage,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "last_page": lastPage,
      };
}

class AllStocks {
  final String? id;
  final String symbol;
  final String? name;
  final String? exchangeShortName;
  final String? image;
  final double? change;
  final String? price;
  final double? changesPercentage;
  final String? dayHigh;
  final String? dayLow;
  final String? open;
  final String? previousClose;

  AllStocks({
    this.id,
    required this.symbol,
    this.name,
    this.exchangeShortName,
    this.image,
    this.change,
    this.price,
    this.changesPercentage,
    this.dayHigh,
    this.dayLow,
    this.open,
    this.previousClose,
  });

  factory AllStocks.fromJson(Map<String, dynamic> json) => AllStocks(
        id: json["_id"],
        symbol: json["symbol"],
        name: json["name"],
        exchangeShortName: json["exchange_short_name"],
        image: json["image"],
        change: json["change"]?.toDouble(),
        price: json["price"],
        changesPercentage: json["changesPercentage"]?.toDouble(),
        dayHigh: json["dayHigh"],
        dayLow: json["dayLow"],
        open: json["open"],
        previousClose: json["previousClose"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "symbol": symbol,
        "name": name,
        "exchange_short_name": exchangeShortName,
        "image": image,
        "change": change,
        "price": price,
        "changesPercentage": changesPercentage,
        "dayHigh": dayHigh,
        "dayLow": dayLow,
        "open": open,
        "previousClose": previousClose,
      };
}
