import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:stocks_news_new/modals/notification_res.dart';
import 'package:stocks_news_new/route/my_app.dart';
import 'package:stocks_news_new/screens/deepLinkScreen/webscreen.dart';
import 'package:stocks_news_new/screens/stockDetails/stock_details.dart';
import 'package:stocks_news_new/screens/tabs/news/newsDetail/new_detail.dart';
import 'package:stocks_news_new/screens/tabs/tabs.dart';
import 'package:stocks_news_new/utils/colors.dart';
import 'package:stocks_news_new/utils/constants.dart';
import 'package:stocks_news_new/utils/theme.dart';
import 'package:stocks_news_new/widgets/spacer_horizontal.dart';
import 'package:stocks_news_new/widgets/spacer_vertical.dart';
//
import '../../widgets/theme_image_view.dart';
import '../blogDetail/index.dart';

class NotificationsItem extends StatelessWidget {
  final NotificationData data;
  const NotificationsItem({super.key, required this.data});

  void _onTap(
    BuildContext context,
  ) {
    try {
      String? type = data.type;
      String? slug = data.slug;
      // Navigator.popUntil(
      //   navigatorKey.currentContext!,
      //   (route) => route.isFirst,
      // );

      if (type == NotificationType.dashboard.name) {
        log("--navigate to dashboard---");
        Navigator.pushNamedAndRemoveUntil(
            navigatorKey.currentContext!, Tabs.path, (route) => false);
      } else if (slug != '' && type == NotificationType.newsDetail.name) {
        log("--navigate to news detail---");

        Navigator.pushNamed(
          navigatorKey.currentContext!,
          NewsDetails.path,
          arguments: {"slug": slug},
        );
      } else if (slug != '' && type == NotificationType.lpPage.name) {
        log("--navigate to landing page---");

        Navigator.push(
          navigatorKey.currentContext!,
          MaterialPageRoute(
            builder: (context) => WebviewLink(
              stringURL: slug,
            ),
          ),
        );
      } else if (slug != '' && type == NotificationType.blogDetail.name) {
        log("--navigate to blog detail---");

        Navigator.push(
          navigatorKey.currentContext!,
          MaterialPageRoute(
            builder: (context) => BlogDetail(
              slug: slug ?? "",
            ),
          ),
        );
      } else {
        log("--navigate to stock detail---");

        Navigator.pushNamed(
          navigatorKey.currentContext!,
          StockDetails.path,
          // arguments: type,
          arguments: {"slug": type},
        );
      }
    } catch (e) {
      log("Exception ===>> $e");
      Navigator.pushNamedAndRemoveUntil(
          navigatorKey.currentContext!, Tabs.path, (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    String date =
        DateFormat("MMM dd, yyyy").format(data.createdAt ?? DateTime.now());

    String time = DateFormat("h:mm a").format(data.createdAt ?? DateTime.now());
    return InkWell(
      onTap: () => _onTap(context),
      // onTap: data.type == "dashboard"
      //     ? () {
      //         Navigator.pushNamedAndRemoveUntil(
      //             navigatorKey.currentContext!, Tabs.path, (route) => false);
      //       }
      //     : data.slug != "" && data.type == ''
      //         ? () {
      //             if (data.slug == '') {
      //               return;
      //             }
      //             Navigator.pushNamed(context, NewsDetails.path,
      //                 arguments: data.slug);
      //           }
      //         : () {
      //             if (data.type == '') {
      //               return;
      //             }

      //             Navigator.pushNamed(context, StockDetails.path,
      //                 arguments: data.type);
      //           },
      borderRadius: BorderRadius.circular(5.sp),
      child: Container(
        decoration: BoxDecoration(
            color: ThemeColors.greyBorder.withOpacity(0.6),
            borderRadius: BorderRadius.circular(5.sp)),
        child: Padding(
          padding: EdgeInsets.fromLTRB(13.sp, 13.sp, 13.sp, 13.sp),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.chat_rounded,
                    color: ThemeColors.accent,
                  ),
                  const SpacerHorizontal(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          data.title,
                          style: stylePTSansRegular(),
                        ),
                        const SpacerVertical(height: 6),
                        Text(
                          data.message,
                          style: stylePTSansRegular(
                              fontSize: 12, color: ThemeColors.greyText),
                        ),

                        // Align(
                        //   alignment: Alignment.centerRight,
                        //   child: Text(
                        //     date,
                        //     style: stylePTSansRegular(fontSize: 13),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ],
              ),
              const SpacerVertical(height: 10),
              Visibility(
                visible: data.image != null && data.image != '',
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5.sp),
                  child: ThemeImageView(
                    url: data.image ?? "",
                    // height: 60.sp,
                    // width: 60.sp,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              const SpacerVertical(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  "$date at $time",
                  style: stylePTSansRegular(
                      fontSize: 12, color: ThemeColors.greyText),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
