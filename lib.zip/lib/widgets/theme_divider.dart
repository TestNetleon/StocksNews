import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stocks_news_new/utils/colors.dart';

class ThemeDivider extends StatelessWidget {
  static const String path = '/invoicePurchase';
//
  const ThemeDivider({
    this.height = 1,
    this.color = ThemeColors.divider,
    super.key,
  });

  final double height;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: height.sp,
      color: color,
      thickness: height.sp,
    );
  }
}
