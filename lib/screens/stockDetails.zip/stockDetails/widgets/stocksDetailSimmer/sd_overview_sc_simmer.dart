import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stocks_news_new/screens/stockDetails/widgets/stocksDetailSimmer/overviewWidget/stocks_footer_detail_simmer.dart';
import 'package:stocks_news_new/screens/stockDetails/widgets/stocksDetailSimmer/overviewWidget/stocks_header_detail_simmer.dart';
import 'package:stocks_news_new/utils/constants.dart';

class StocksDetailOverviewScreenSimmer extends StatelessWidget {
  const StocksDetailOverviewScreenSimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.only(
          left: Dimen.padding.sp,
          right: Dimen.padding.sp,
        ),
        child: const Column(
          children: [StocksHeaderDetailSimmer(), StocksFooterDetailSimmer()],
        ),
      ),
    );
  }
}
